class LoginFailure{
  final String message;
 const LoginFailure([ this.message = "Invalid email or password"]);
}