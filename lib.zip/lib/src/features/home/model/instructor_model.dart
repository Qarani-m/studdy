class Instructor{
  int? id;
  String? name;
  String? instructorId;
  String? title;

}