class LessonModel{
  String? lessonId;
  String? lessonTitle;
  String? videoUrl;
  String? watchTime;
}